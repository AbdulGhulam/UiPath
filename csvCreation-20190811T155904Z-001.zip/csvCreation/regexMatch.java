import java.util.*;
import java.io.*;
import java.util.regex.*; 
import java.lang.*;


public class regexMatch{
    
    public String matchAttempt(String fileName, String fileName2){
        try{
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        BufferedReader br2 = new BufferedReader(new FileReader(fileName2));
        String text = br2.readLine();
        text = text.toLowerCase();
        for(String line; (line = br.readLine()) != null; ) {
                String[] temp = line.split("->");
                if(text.matches(temp[0])){
                    br2.close();
                    br.close();
                    return line;
                }
            }
        br2.close();
        br.close();  
    }
    catch(IOException ex) {
        System.out.println("error");
    }
    return "0"; 
    }
    
}
