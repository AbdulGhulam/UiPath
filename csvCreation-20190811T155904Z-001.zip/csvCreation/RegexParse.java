
    import java.util.*;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
import java.lang.*;

public class RegexParse{
    Vector<String> rows = new Vector<String>();
    
    public void parse(String fileName, String line, String fileName3){
        try{
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String[] temp = line.split("->");
            System.out.println(temp[0]);
            int firstMonth = temp[1].indexOf("MONTH");
            int firstDay = temp[1].indexOf("DAY");
            int firstYear = temp[1].indexOf("YEAR");
            int firstDesc = temp[1].indexOf("DESC");
            int lastMonth = temp[1].lastIndexOf("MONTH");
            int lastDay = temp[1].lastIndexOf("DAY");
            int lastYear = temp[1].lastIndexOf("YEAR");
            int lastDesc = temp[1].lastIndexOf("DESC");
            String monthRegex = temp[1].substring(firstMonth+5,lastMonth);
            String dayRegex = temp[1].substring(firstDay+3,lastDay);
            String yearRegex = temp[1].substring(firstYear+4,lastYear);
            String DescRegex = temp[1].substring(firstDesc+4,lastDesc);
            String temp4[] = {monthRegex, dayRegex, yearRegex, DescRegex};
            //String descRegex = temp[1].substring(firstDesc+4,lastDesc);
           
        String lineTemp = br.readLine();
        while(lineTemp != null) {
               lineTemp = lineTemp.toLowerCase(); 
        if (lineTemp.matches(temp[0])) {
            
                for(int i = 0; i < 4; i++) {
                    //System.out.println(temp4[i]);
                Pattern pattern = Pattern.compile(temp4[i]);
                Matcher matcher = pattern.matcher(lineTemp);
                matcher.find();
                lineTemp = lineTemp.replaceFirst((matcher.group(0)),"");
                if(temp4[i] ==DescRegex){
                    String temp12 = matcher.group(0);
                    temp12 = temp12.replaceAll(",","");
                    rows.add(temp12);
                }
                else if(temp4[i] ==yearRegex){
                    rows.add("2020");
                }
                    else{
                rows.add((matcher.group(0)).replaceAll("[^a-zA-Z0-9]", ""));
            }
            }}
            lineTemp = br.readLine();
            }
            BufferedWriter b1 = new BufferedWriter(new FileWriter(fileName3));
        StringBuilder sb = new StringBuilder();

            // Append strings from array
                for (String element : rows) {
                    sb.append(element);
                    sb.append(",");
                }

                b1.write(sb.toString());
                b1.close();
            
        }
        catch(IOException ex) {
            ex.printStackTrace();
        }
        

    }
    

}


