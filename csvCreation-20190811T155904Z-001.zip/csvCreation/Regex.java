import java.util.*;

public class Regex {
    public static void main(String [ ] args) {
        regexMatch rm = new regexMatch();
        RegexParse rp = new RegexParse();
        String s = rm.matchAttempt(args[0], args[1]);
        rp.parse(args[1], s, args[2]);
    }
}
